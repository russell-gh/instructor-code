# Answers

1. What does HTML stands for?
   HyperText Markup Language

2. What 'things' does HTML use to 'mark up' a document
   tags

3. The very first line of an HTML file is the Doctype. What does it do?
   Tells the browser what version of HTML it is, so it knows what rules to load and hence what tags are available and how they work.

4. After that comes the first set of tags. What are they?
   html tags

5. What is the written difference between a tag and an element?
   Tag is in the code. Element is the thing in the page.

6. Tags can be put inside one another (e.g. an `<a>` in a `<nav>`). What is this called? What do we do in our formatting to show that an element is inside another?
   Nesting. We indent.

7. What is the difference between an opening and a closing tag?
   the closing tag has a `/` before the tag name

8. There are some tags which don't have content (and so don't need closing). What is the name for these tags? Name 4 of them.
   Self-closing. img, input, hr, link

9. The first child of an HTML tag is the head tag. List 3 things that go in it.
   meta tags, title, stylesheets

10. In the browser tab there are words. Which tag puts them there?
    Title tag

11. What is the name of the little image that goes next to it? How does it get there?
    Favicon. You need to link them with meta tags.

12. What metatag is necessary for media queries to work?
    Viewport

13. What do we call the area of the browser which displays the web page?
    Viewport

14. What are attributes? What is the format for adding one to a tag?

They give additional info about how a tag works, like an images source or a links destination.

write tag name then space then attribute `<attributename>="<value>"`

15. How do you put a link in a page?

`<a href="<destination>">Text goes here</a>`

16. How do you put an image in a page?
    `<img src="<location of image file>" alt="text if image no show">`

17. The `<something>` tag comes after the head and inside the html tag. It contains the code for the elements which we can see. What is the something?
    body

18. Semantically we use 'sectioning tags' to break the page down into parts. Can you name 6 sectioning tags?
    header, main, nav, aside, footer, section

19. Inside the sectioning tags we add content like headings: How many levels of headings are there? When do you go down a level? Should you use them for sizing? Can you have more than one `<h1>` on a page? If you do are there any consequences?

6 levels. `<h1>` to `<h6>`. Should go down when it is a sub-heading of a previous heading. No for sizing. You can have more than one h1 on a page, it just makes the h1s less valuable in SEO

20. `<p>` is the paragraph tag. It holds text in paragraphs. What tags can I use if I want to make certain text 'stand out' meaning-wise?
    strong, em, b

21. If I want to group elements together what tag do I use?
    div

22. If I want to group pieces of text together what tag do I use?
    span

23. What types of list are availble to me?
    unordered, ordered, definition.

24. What are the only elements that can be a direct child of one of these lists? (ignoring definition lists)
    List items `<li>`

25. What is the tag for a definition list? What are the two tags that go inside it and what do they represent?
    `<dl>`. `<dt>` - definition term; `<dd>` - definition details

26. HTML has tables. What are the tags that can go immediately inside a table tag?
    tbody, tfoot, thead, tr. (no tbody of trs already present) (plus caption)

27. The cells of the tables are held in rows. What is the tag for this?
    `<tr>` table row tag

28. Some cells are heading cells. What is the tag for that? What is the attribute that shows to what the heading applies?
    `<th>` table header cell. `scope="row | col"`

29. What is the tag for a normal cell?
    `<td>` table data cell

30. FORMS: What does a form do?
    Sends data to a server

31. What attribute on the form tag decides WHERE the information is sent? What is the default if it is not set?
    action (default: current URL in browser address bar)

32. What attribute defines HOW it is sent? (And what is the default). Which method should I use to send sensitive info, like passwords, etc?
    method. GET and POST are options. [GET is default] Use POST for secure, otherwise it will be viewable in the request url.

33. Name 6 types of text input.
    text, number, email, tel, date, password

34. What is the tag for a dropdown list? What attribute allows it to have more than one from the list selectable?
    select tag. `multiple` keyword

35. What goes in a dropdown list? What attribute is required on it to determine what is sent if it differs from the text of that element?
    option tags. Need a 'value' attribute if value to be sent is different from what's in the text node.

36. What is the other (round) input type where you can only select one of them? What attribute must be identical to make this behaviour happen?
    Radio button. Name attribute must be the same

37. What type of the (square) input lets you select a few of them?
    Checkbox

38. What is the tag for a large text box with multiple lines?
    `<textarea>`

39. What is needed to submit the form? (Or more, what element should you put in your form so that a user can submit it when they are ready?!)
    button

40. How is the data sent labelled? (e.g. what attribute do you need to have on each to show that that value means that thing?)

    the data from each input is put in the formdata against the key of whatever that/those element's 'name' attribute was.

41. CSS! What are the parts of a CSS rule?
    selector chain; declarations (`<property>: <value>;`)

42. A selector chain determines what the rules apply to. Which direction is it read in by the browser?
    right to left

43. If I have a list in a list, what will `ul li` select? How would I override that?
    You'll get both the lis and nested lis. To select the nested ones you'll need a rule for `ul li li`.

44. CSS overrides in two ways. What are they?
    order and specificity

45. What is the least specific type of selector in CSS? (not counting the `*`)
    element
46. How do you show a class selector? How do you select an element with has 2 classes on it?
    `.<classname>` For adjacent selectors you do `.<classname>.<classname>`

47. How do you select an element by its ID? Why shouldn't you?
    '#' to specify an ID. It's too specific (i.e. difficult to override)

48. In the HTML which 'global attribute' lets us put CSS directly on elements? Is it a good idea for you to do it normally?
    `style=""`. No, it's not. It's even more specific than the ID selector.

49. What is CSSs ultimate override. (It is a keyword you put next to a value and is the last thing level in the specificity model)
    !important

50. What would be a good selector for email links?
    a[href^="mailto://"]

51. How would I select every 5th item in a list? What is this type of selector called?
    `<items>:nth-child(5n)` pseudo selector

52. How would I select a button that is hovered? What is this type of selector called? What is the twin of hover [that we use for keyboard accessibility]?
    button:hover button:focus pseudo-selector (pseudo-class)
    
53. There appears to already be some CSS in my page, even if I don't write any myself. What is this called? How do I get rid of or standardise it?
    User-agent stylesheets.
    CSS Reset or normalise

54. OK, onto properties: How do you change the colour of the text in an element?
    `color: <value>;`

55. Do I need to do that for every single element? (Hint: no!) Why not? What is built into CSS that allows property values to be passed down to children, etc?
    CSS inheritance

56. What is the rule for which one wins? What keyword forces it to win over rules that directly target the element? What is the keyword that resets to the browser's CSS?

    The closest wins. The `inherit` keyword will take the inherited value. The `initial` keyword will reset to the browsers initial values.

57. What 4 ways can we express colour?
    colour names, hex(a), rgb(a), hsl(a)

58. What is 'alpha channel'? (As in RGBa[lpha]:`rgba(<red>, <green>, <blue>, <alpha>)`)
    Transparency

59. How do I set a background colour?
    `background-color: <color>;`

60. How do I set a background image?
    `background-image: url(<path>);`

61. How do I stop it repeating?
    `background-repeat: no-repeat;`

62. How do I get it to go over the whole area of the element leaving no spaces but possibly losing some of the image?
    `background-size: cover;`

63. How would I make sure that an image is displayed uncropped inside an element. What happens to the extra space not covered by it?
    `background-size: contain;` background color on that element (if set/not transparent) shows through. (or els below it)

64. What is the relationship between an image's height and width called?
    aspect ratio

65. What size will the image be in the page if it is pulled in by an image tag?
    Its intrinsic size.

66. How could I combat this?
    Put a width or height on it.

67. What size will a background image hold an element open to?
    It won't.

68. OK, Layout. What are the 4 constituent parts of the box model?
    Margin, border, padding, content.

69. What are they used for?
    Margin: External space; border ...; padding: internal space. Content...;

70. How does the `display` property play into them?
    Setting different display values changes how these are interpretted, for example, inline elements cannot have a vertical margin and can have only a visible padding, but not one that pushes. Change that to inline-block or block and they work normally.

71. What 3 parts are there to declaring a border?
    border-width, border-style, border-color  (and now border-image)

72. What special value can be used to put an element in the center of its parent? Which box model property is that used with?
    margin: auto;

73. If you say 'width' on an element, what does that refer to? Can you change it?
    Naturally it refers to the content of the box. If you set `box-sizing: border-box;` then you change that to include border and padding too.

74. What is the difference between a border and an outline?
    outline takes up no space (and is not necessarily square)

75. What 4 layout methods are there?
    table
    float
    flexbox
    grid

76. How can I adjust my CSS to apply different rules at different screen sizes? Write an example one...
    Media queries:

```CSS
@media screen and (min-width: 601px){
  /* rules go here */
}
```

77. What is float normally used for?
    To let text wrap around an image.

78. If I have a parent element, like a header, and I have a logo and a nav as children and I float them both, what happens to the header element?
    It collapses to zero height.

79. How do I fix this?
    overflow hidden or auto OR clearfix fix.

80. In flexbox, how do you align elements horizontally (when flex-direction is row)
    `justify-content`

81. What's the difference between 'align-content' and 'align-items'?
    Align items aligns the items relative to their line; align content aligns the lines of items relative to the container.

82. Can a child item override its cross-axis alignment?
    yes. align-self.

83. If I make a list of flex items wider than the container and they don't go onto the next line, what do I need to change?
    You need to set `flex-wrap: wrap;`, because the default is `nowrap`.

84. How do I make them grow and shrink?
    flex[-grow, -shrink]. put a number for a ratio of growth/shrinkage. `flex-grow: 2;` gets twice the spare space given to it when it grows

85. What is flex-basis? And what does `auto` do?
    It's the base size for an element before any space is distributed during flexing. `auto` means 'take this from my width/height`.

86. Back to normal CSS, what values are there for `overflow`?
    hidden, auto, visible, scroll

87. Name 4 (or 5, if you're feeling adventurous) types of `position` and what they do and when you'd use them?

- `static` is the default (and canceller)
- `fixed` positions the element relative to the viewport
- `relative` moves where it is appears, but not where it is. (It also provides bounds for absolute)
- `absolute` puts things over things. Takes an element 'out of the flow of the document' and positions it over something else (relative to the last 'relatively-positioned parent)
- `sticky` positions an element relative to its parent, then moves it as the document scrolls pass

88. What CSS properties would you use with them to adjust the position of an element?
    top, bottom, left, right

89. OK, grid-systems! Name 2 famous frameworks with grid systems!
    Bootstrap
    Materialize

90. What are the measurements called that we use to determine when our grid should apply different rules? (e.g. `(max-width: <what's this>)`)
    Breakpoints

91. In a grid system (not CSS grid, yet), What are the three parts? (Hint: 1 restricts width and contains the elements; the next puts them together in groups that sit next to each other [bit like a certain table element], and; one that puts them next to each other)
    container, row, column.

92. A grid is often divided into how many parts? Why?
    '12' because it divides neatly into halves, thirds and quarters.

93. CSS GRID TIME: What 2 ways can you turn an element into a grid container?
    `display: grid;` and `display: inline-grid;`

94. How do you define columns and rows?
    `grid-template-rows` and `grid-template-columns`

95. What is an `fr` unit? How does it work with the `auto` keyword?
    Fraction. Takes up 1 fraction of the spare space. `auto` is the computers best guess. On its own it grows like 1fr but if an fr unit is present then it shrinks to the size of its content.

96. How do you limit a row or column to be between two lengths?
    `minmax(<min>, <max>)`

97. What is a grid line and what numbering system do they use?
    They are the lines that define boundaries in the grid. Going in the direction of the page they are labled. 1++ (ascending) and -1++ (the other direction)

98. How do you declare a line in your grid? How do you declare multiple line names
    `grid-template-columns: [name other-name next-line];`

99. How do I go across several lines if I don't know their name?
    `span` keyword

100.  How do I put an item in an area?
      `grid-area: <name>`
