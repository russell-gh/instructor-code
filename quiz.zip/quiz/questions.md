# Questions

1. What does HTML stands for?
2. What `<things>` does HTML use to 'mark up' text
3. The very first line of an HTML file is the Doctype. What does it do?
4. After that comes the first set of tags. What are they?
5. What is the difference between a tag and an element?
6. Tags can be put inside one another (e.g. an `<a>` in a `<nav>`). What is this called? What do we do in our formatting to show that an element is inside another?
7. What is the written difference between an opening and a closing tag?
8. There are some tags which don't have content (and so don't need closing). What is the name for these tags? Name 4 of them.
9. The first child of an HTML tag is the head tag. List 3 things that go in it.
10. In the browser tab there are words. Which tag puts them there?
11. What is the name of the little image that goes next to it? How does it get there?
12. What metatag is necessary for media queries to work?
13. What do we call the area of the browser which displays the web page?
14. What are attributes? What is the format for adding one to a tag?
15. How do you put a link in a page?
16. How do you put an image in a page?
17. The `<something>` tag comes after the head and inside the html tag. It contains the code for the elements which we can see. What is the something?
18. Semantically we use 'sectioning tags' to break the page down into parts. Can you name 6 sectioning tags?
19. Inside the sectioning tags we add content like headings: How many levels of headings are there? When do you go down a level? Should you use them for sizing? Can you have more than one `<h1>` on a page? If you do are there any consequences?
20. `<p>` is the paragraph tag. It holds text in paragraphs. What tags can I use if I want to make certain text 'stand out' meaning-wise?
21. If I want to group elements together what tag do I use?
22. If I want to group pieces of text together what tag do I use?
23. What types of list are availble to me?
24. What are the only elements that can be a direct child of one of these lists? (ignoring definition lists)
25. What is the tag for a definition list? What are the two tags that go inside it and what do they represent?
26. HTML has tables. What are the tags that can go immediately inside a table tag?
27. The cells of the tables are held in rows. What is the tag for this?
28. Some cells are heading cells. What is the tag for that? What is the attribute that shows where to what the heading applies?
29. What is the tag for a normal cell?
30. FORMS: What does a form do?
31. What attribute on the form tag decides WHERE the information is sent? What is the default if it is not set?
32. What attribute defines HOW it is sent? (And what is the default). Which method should I use to send sensitive info, like passwords, etc?
33. Name 6 types of text input.
34. What is the tag for a dropdown list? What attribute allows it to have more than one from the list selectable?
35. What goes in a dropdown list? What attribute is required on it to determine what is sent if it differs from the text of that element?
36. What is the other (round) input type where you can only select one of them? What attribute must be identical to make this behaviour happen?
37. What type of input (square) lets you select a few of them?
38. What is the tag for a large text box with multiple lines?
39. What is needed to submit the form? (Or more, what element should you put in your form so that a user can submit it when they are ready?!)
40. How is the data sent labelled? (e.g. what attribute do you need to have on each to show that that value means that thing?)
41. CSS! What are the parts of a CSS rule?
42. A selector chain determines what the rules apply to. Which direction is it read in by the browser?
43. If I have a list in a list, what will `ul li` select? How would I override that?
44. CSS overrides in two ways. What are they?
45. What is the least specific type of selector in CSS? (not counting the `*`)
46. How do you show a class selector? How do you select an element with has 2 classes on it?
47. How do you select an element by its ID? Why shouldn't you?
48. In the HTML which 'global attribute' lets us put CSS directly on elements? Is it a good idea for you to do it normally?
49. What is CSSs ultimate override. (It is a keyword you put next to a value and is the last thing level in the specificity model)
50. What would be a good selector for email links?
51. How would I select every 5th item in a list? What is this type of selector called?
52. How would I select a button that is hovered? What is this type of selector called? What is the twin of hover [that we use for keyboard accessibility]?
53. There appears to already be some CSS in my page, even if I don't write any myself. What is this called? How do I get rid of or standardise it?
54. OK, onto properties: How do you change the colour of the text in an element?
55. Do I need to do that for every single element? (Hint: no!) Why not? What is built into CSS that allows property values to be passed down to children, etc?
56. What is the rule for which one wins? What keyword forces it to win over rules that directly target the element? What is the keyword that resets to the browser's CSS?
57. What 4 ways can we express colour?
58. What is 'alpha channel'? (As in RGBa[lpha]: `rgba(<red>, <green>, <blue>, <alpha>)`)
59. How do I set a background colour?
60. How do I set a background image?
61. How do I stop it repeating?
62. How do I get it to go over the whole area of the element leaving no spaces but possibly losing some of the image?
63. How would I make sure that an image is displayed uncropped inside an element. What happens to the extra space not covered by it?
64. What is the relationship between an image's height and width called?
65. What size will the image be in the page if it is pulled in by an image tag?
66. How could I combat this?
67. What size will a background image hold an element open to?
68. OK, Layout. What are the 4 constituent parts of the box model?
69. What are they used for?
70. How does the `display` property play into them?
71. What 3 parts are there to declaring a border?
72. What special value can be used to put an element in t he center of its parent? Which box model property is that used with?
73. If you say 'width' on an element, what does that refer to? Can you change it?
74. What is the difference between a border and an outline?
75. What 4 layout methods are there?
76. How can I adjust my CSS to apply different rules at different screen sizes? Write an example one...
77. What is float normally used for?
78. If I have a parent element, like a header, and I have a logo and a nav as children and I float them both, what happens to the header element?
79. How do I fix this?
80. In flexbox, how do you align elements horizontally
81. What's the difference between 'align-content' and 'align-items'?
82. Can a child item override its cross-axis alignment?
83. If I make a list of flex items wider than the container and they don't go onto the next line, what do I need to change?
84. How do I make them grow and shrink?
85. What is flex-basis? And what does `auto` do?
86. Back to normal CSS, what values are there for `overflow`?
87. Name 4 (or 5, if you're feeling adventurous) types of `position` and what they do and when you'd use them?
88. What CSS properties would you use with them to adjust the position of an element?
89. OK, grid-systems! Name 2 famous frameworks with grid systems!
90. What are the measurements called that we use to determine when our grid should apply different rules? (e.g. `(max-width: <what's this>)`)
91. In a grid system (not CSS grid, yet), What are the three parts? (Hint: 1 restrics width and contains the elements; the next puts them together in groups that sit next to each other [bit like a certain table element], and; one that puts them next to each other)
92. A grid is often divided into how many parts? Why?
93. CSS GRID TIME: What 2 ways can you turn an element into a grid container?
94. How do you define columns and rows?
95. What is an `fr` unit? How does it work with the `auto` keyword?
96. How do you limit a row or column to be between two lengths?
97. What is a grid line and what numbering system do they use?
98. How do you declare a line in your grid? How do you declare multiple line names
99. How do I go across several lines if I don't know their name?
100. How do I put an item in an area?
