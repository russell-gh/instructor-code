import React, { Component } from "react";

class Login extends Component {
  render() {
    return (
      <>
        Email
        <input type="text" />
        Password
        <input type="text" />
        <button
          onClick={() => {
            if (/* check creds on server */ 1 === 1) {
              this.props.onLogin();
            }
          }}
        >
          Login
        </button>
      </>
    );
  }
}

export default Login;
