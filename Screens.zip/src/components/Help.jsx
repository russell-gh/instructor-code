const Help = () => {
  return <h1>Help screen</h1>;
};

export default Help;
