const Dashboard = () => {
  return <h1>Dashboard screen</h1>;
};

export default Dashboard;
