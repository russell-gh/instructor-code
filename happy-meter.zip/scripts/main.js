document.addEventListener("DOMContentLoaded", () => {
  const moods = {};
  let moodNames = [];

  function formatData(data) {
    if (!data)
      throw new Error(`No data provided to formatData. Received ${data}`);
    const { happy, ok, sad } = data;
    return [
      {
        label: "happy",
        value: happy,
      },
      {
        label: "ok",
        value: ok,
      },
      {
        label: "sad",
        value: sad,
      },
    ];
  }

  function drawGraph(data, mountNodeSelector = "#chart svg") {
    console.log("drawGraph data", data);

    nv.addGraph(function () {
      var chart = nv.models
        .pieChart()
        .x((d) => d.label)
        .y((d) => d.value)
        .showLabels(true);

      d3.select(mountNodeSelector)
        .datum(data)
        .transition()
        .duration(350)
        .call(chart);

      return chart;
    });
  }

  // Initialize Firebase
  // Your web app's Firebase configuration
  var firebaseConfig = {
    // apiKey: "AIzaSyCnwbH0wcdwpu7qfMQRwKBAlmEbVXyDy10",
    // authDomain: "test5000-b513d.firebaseapp.com",
    // projectId: "test5000-b513d",
    // storageBucket: "test5000-b513d.appspot.com",
    // messagingSenderId: "514942080268",
    // appId: "1:514942080268:web:c65273a19216aa380de529",

    apiKey: "AIzaSyCSETjJ79FfZaIg7p5h5TIc-N89JOkfLO4",
    authDomain: "thursday-test-cohort-6.firebaseapp.com",
    projectId: "thursday-test-cohort-6",
    storageBucket: "thursday-test-cohort-6.appspot.com",
    messagingSenderId: "498057859772",
    appId: "1:498057859772:web:3f5518c476f5d93a5736b9",
  };
  // Initialize Firebase
  firebase.initializeApp(firebaseConfig);

  const db = firebase.firestore();
  const moodsCollectionRef = db.collection("moods");

  // Initial get
  moodsCollectionRef.get().then((snapshot) => {
    snapshot.forEach((childSnapshot) => {
      const { id } = childSnapshot;
      moodNames.push(id);
      const { value } = childSnapshot.data();
      console.log("value", value);
      moods[id] = value;
    });
  });

  moodsCollectionRef.onSnapshot((snapshot) => {
    snapshot.docChanges().forEach(function (change) {
      console.log("change", change);
      if (change.type === "added") {
        console.log("New tutorial: ", change.doc.data());
      }
      if (change.type === "modified") {
        console.log("Modified tutorial: ", change.doc.data());
      }
      if (change.type === "removed") {
        console.log("Removed tutorial: ", change.doc.data());
      }
      moods[change.doc.id] = change.doc.data().value;
    });

    drawGraph(formatData(moods));
  });

  async function incrementField(field) {
    if (typeof field !== "string" || !moodNames.includes(field))
      throw new Error(
        `Received ${field} for a mood. Expected one of: ${moodNames.join()}`
      );

    try {
      await moodsCollectionRef.doc(field).update({
        value: moods[field] + 1,
      });
      console.log("Document successfully updated!");
    } catch (error) {
      // The document probably doesn't exist.
      console.error("Error updating document: ", error);
    }
  }

  // DOM ELEMENTS (You could create these dynamically from the DB, but I kept it simple...)
  const happyButton = document.getElementById("happy");
  const okButton = document.getElementById("ok");
  const sadButton = document.getElementById("sad");

  // Event Listeners
  happyButton.addEventListener("click", () => {
    console.log("making happy");
    incrementField("happy");
  });
  okButton.addEventListener("click", () => {
    console.log("making ok");
    incrementField("ok");
  });
  sadButton.addEventListener("click", () => {
    console.log("making sad");
    incrementField("sad");
  });
});
