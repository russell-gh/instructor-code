# Quick guide article 

Article: <https://dev.to/khattakdev/nodejs-understanding-streams-5gjh>
Cheat Sheet: <https://nodesource.com/blog/understanding-streams-in-nodejs/>