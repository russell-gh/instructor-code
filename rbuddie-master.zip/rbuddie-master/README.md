# RBuddie - QR Code Scanner App built in React.js
RBuddie is a digital receipt app that helps you keep track of transactions and store all your receipts in one place. The app can scan valid RBuddie QR Codes containing receipt data.

