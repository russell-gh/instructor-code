aniversary reminder

1 landing, question if you are married: yes or no.aniversary

1.1 no = goodbey

2 yes = set up of functionalities (wedding date, partener name, celebrations in common....)
