import { Router } from "express";
import { IdGenerator } from "./utils/idGen";
export const router = Router();
/* GET ROUTES
Exposing all leaderboard entries and single leaderboard entry filtered by username */

router.get("/leaderboard", (req, res) => {
  res.send({ status: 1, message: "request complete", data: req.data });
});

router.get("/leaderboard/:username", (req, res) => {
  const username = req.params.username;

  const filtered = req.data.filter((item) => {
    return item.username === username;
  });

  if (filtered.length === 0) {
    res.send({
      status: 0,
      message: "no username found",
    });
  } else {
    res.send({
      status: 1,
      message: "request complete",
      data: filtered,
    });
  }
});

/* POST ROUTES
Exposing the ability to add a new entry to the leaderboard */

router.post("/entry", (req, res) => {
  const { username, date } = req.body;
  const highscore = parseInt(req.body.highscore);

  // defensive check against incomplete request body
  if (!username || !highscore || !date) {
    return res.send({ status: 0, message: "Incomplete request" });
  }

  // defensive check against incorrect data types
  if (
    typeof username !== "string" ||
    Number.isNaN(highscore) ||
    highscore < 0
  ) {
    return res.send({ status: 0, message: "Invalid request" });
  }

  if (["mierda", "tonto", "loco"].includes(username)) {
    return res.send({ status: 0, message: "Invalid Username" });
  }

  // defensive check against duplicate leaderboard entries
  const index = req.data.findIndex((el) => {
    return username === el.username;
  });
  if (index !== -1) {
    return res.send({ status: 0, message: "duplicate entry" });
  }

  // adds only required data to the database
  req.data.push({
    username: username,
    highscore: highscore,
    date: date,
    id: IdGenerator(username, 10),
  });

  res.send({ status: 1, message: "entry added successfully" });
});

/* PATCH ROUTES
Exposing the ability to update the score of a current entry */

router.patch("/entry/:username/:highscore", (req, res) => {
  const { username } = req.params;
  const highscore = parseInt(req.params.highscore);

  if (Number.isNaN(highscore) || highscore < 0) {
    return res.send({ status: 0, message: "invalid data" });
  }

  const filtered = req.data.filter((item) => {
    return item.username === username;
  });
  if (filtered.length === 0) {
    return res.send({
      status: 0,
      message: "no username found",
    });
  }

  const index = req.data.findIndex((el) => {
    return el.username === username;
  });

  req.data[index].highscore = highscore;

  res.send({
    status: 1,
    message: "entry updated",
  });
});

/* DELETE ROUTES
Exposing the ability to remove an entry from the leaderboard*/

router.delete("/entry/:username", (req, res) => {
  const username = req.params.username;

  const filtered = req.data.filter((item) => {
    return item.username === username;
  });
  if (filtered.length === 0) {
    res.send({
      status: 0,
      message: "no username found",
    });
  }

  const index = req.data.findIndex((el) => {
    return el.username === username;
  });

  if (index === -1) {
    res.send({ status: 0, reason: "User not found." });
  }

  req.data.splice(index, 1);

  res.send({
    status: 1,
    message: "entry deleted",
  });
});
