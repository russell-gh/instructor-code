export function IdGenerator(username: string, len: number = 16) {
  const chars: string =
    "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
  let id: string[] = [];
  for (let i = 0; i < len; i++) {
    id.push(chars[Math.floor(Math.random() * chars.length)]);
  }
  return `${id.join("")}-${username}`;
}
