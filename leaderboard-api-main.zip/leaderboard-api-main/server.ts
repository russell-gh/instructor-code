import express, { Express, Request, Response } from "express";
import * as lbData from "./data.json";
import { router } from "./router";
const app: Express = express();
const PORT: number = Number(process.env.PORT) || 6001;

declare global {
  namespace Express {
    interface Request {
      data: Array<{
        username: string;
        highscore: number;
        id: string;
        date: string;
      }>;
    }
  }
}

app.use((req: Request, res: Response, next) => {
  console.log("new request received!");
  req.data = lbData;
  next();
});

app.use(express.json());

app.use("/get", router);
app.use("/post", router);
app.use("/patch", router);
app.use("/delete", router);

app.listen(PORT, () => {
  console.log(`server is running on 'localhost:${PORT}`);
});
