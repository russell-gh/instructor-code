import React from "react";

const Home = () => {
  return <h1>home</h1>;
};

export default Home;
