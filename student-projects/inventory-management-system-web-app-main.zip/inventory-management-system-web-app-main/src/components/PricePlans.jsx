import React from "react";

const PricePlans = () => {
  return <h1>Price Plan</h1>;
};

export default PricePlans;
