export const useagePlugins = {
  legend: {
    position: "top",
  },
  title: {
    display: true,
    text: "Stock Usage",
  },
};
