### CIMS-Backend

An express api for [cims](https://github.com/michael86/inventory-management-system-web-app)

## Notes

Need to send unix timestamp to invoice route and update db to accept unix as a timestamp

## To do

...
