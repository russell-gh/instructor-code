const express = require("express");
const app = express.Router();
const utils = require("../utils.js");
const carSchema = require("../database/mongoSchema");
const mongoose = require("mongoose");

app.post("/", (req, res) => {
  const Car = new mongoose.model("Car", carSchema);
  const car = new Car({ make: req.body.make, model: req.body.model });
  car.save();

  res.send("Car added!");
});

app.get("/", (req, res) => {
  res.send(req.cars);
});

app.delete("/:make", (req, res) => {
  const indexOfCar = req.cars.findIndex((car) => car.make === req.params.make);
  req.cars.splice(indexOfCar, 1);
  res.send("Car deleted");
});

app.put("/", (req, res) => {
  const indexOfCar = utils.getIndexViaMake(req.cars, req.body.old_make);

  if (indexOfCar > -1) {
    req.cars[indexOfCar].make = req.body.new_make;
    res.send("Yay, updated!");
  } else {
    res.send("Sorry, car not found");
  }
});

module.exports = app;
