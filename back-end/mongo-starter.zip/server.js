const express = require("express");
const app = express();
const cors = require("cors");
const bodyParser = require("body-parser");
const mongooseConnection = require("./database/mongoose");

const cars = [];
app.use((request, response, next) => {
  request.mongooseConnection = mongooseConnection;
  request.cars = cars;
  next();
});

app.use(cors());
app.use(bodyParser.json());

app.use("/", require("./routes/index"));

const port = process.env.PORT || 6001;
app.listen(port, () => {
  console.log("Server running on port:", port);
});
