module.exports = {
  getIndexViaMake: (cars, make) => {
    return cars.findIndex((car) => car.make === make);
  },
};
