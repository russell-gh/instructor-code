//import mongoose
const mongoose = require("mongoose");

//connect to mongoose
mongoose.connect("mongodb://localhost:27017", { useNewUrlParser: false });

//grab connection
const db = mongoose.connection;

//detect an error
db.on("error", () => console.log("MongoDB Error"));

//once connection is up and running
db.once("open", () => {
  console.log("DB connection is all working!");
});

//a dog is
let dogSchema = new mongoose.Schema({
  name: String,
  destination: String,
  height: String,
  expensive: Boolean,
});

dogSchema.method.speak = () => {
  console.log(`${this.name} is heading towards ${this.destination}`);
  return;
};

//create model
const Dog = mongoose.model("Dog", dogSchema);

//create an instance
const roland = new Dog({
  name: "Roland",
  destination: "London",
  height: "Tall",
  expensive: true,
});
const chip = new Dog({
  name: "Chip",
  destination: "Glasgow",
  height: "Short",
  expensive: false,
});

roland.save((err, items) => {
  console.log(err, items);
});
chip.save((err, items) => {
  console.log(err, items);
});

Dog.remove({ name: "Roland" }, (err, results) => {
  console.log(err, results);
});

Dog.find((err, results) => {
  console.log(err, results);
});
