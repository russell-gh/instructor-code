const express = require("express");
const { connect } = require("http2");
const app = express();
const mysql = require("mysql");
const sha256 = require("sha256");
require("dotenv").config();
const sendEmail = require("./email");

app.use(express.json());

const connection = {};
connection.mysql = mysql.createConnection({
  database: process.env.DATABASE,
  user: process.env.USER,
  password: process.env.PASSWORD,
  host: process.env.HOST,
  port: process.env.PORT,
});
connection.mysql.connect();

app.post("/signup", (request, response) => {
  const hashedPassword = sha256(request.body.password + "+russellsapp");

  const query = `INSERT INTO users (email, hashedPassword) 
                    VALUES ("${request.body.email}", 
                            "${hashedPassword}")`;

  connection.mysql.query(query, (error, results) => {
    console.log(error, results);
  });
});

app.post("/login", (request, response) => {
  const hashedPassword = sha256(request.body.password + "+russellsapp");

  const query = `SELECT id, count(*) as count FROM users
                    WHERE email = "${request.body.email}"
                        AND hashedPassword = "${hashedPassword}"`;

  connection.mysql.query(query, (error, results) => {
    if (results[0].count === 1) {
      //send a token
      const token = Math.random() * 100000000000000000;

      const query = `INSERT INTO tokens (id, token) VALUES (${results[0].id}, "${token}")`;
      connection.mysql.query(query, (error, request) => {
        console.log("Token stored!");
      });

      response.json({ token });
    } else {
      response.send("WRONG PASSWORD!");
    }
  });
});

app.get("/password_reset/:email", (request, response) => {
  console.log("User requested password reset!", request.params.email);

  //resertthe users password in the database
  const newPassword = Math.floor(Math.random() * 10000000000);
  const hashedPassword = sha256(newPassword + "+russellsapp");

  const query = `UPDATE users SET hashedPassword = "${hashedPassword}"
                  WHERE email = "${request.params.email}"`;

  connection.mysql.query(query, (error, results) => {
    console.log(error, results, newPassword);
    //uncomment below if you create a send in blue account
    //sendEmail(request.params.email, newPassword);
    response.json({ ok: 1 });
  });
});

const nodePort = process.env.NODE_PORT || 6001;

app.listen(nodePort, () => {
  console.log("The server is running on port: " + nodePort);
});
