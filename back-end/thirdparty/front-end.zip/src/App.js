import React, { Component } from "react";
import axios from "axios";

class App extends Component {
  state = { email: "" };
  passwordReset = async () => {
    const result = await axios.get(
      `http://localhost:6001/password_reset/${this.state.email}`
    );
    console.log(result);
  };

  render() {
    return (
      <div>
        Reset Password:
        <input
          onInput={(e) => this.setState({ email: e.target.value })}
          id="email "
          type="text"
        />
        <button onClick={this.passwordReset}>Reset password</button>
      </div>
    );
  }
}

export default App;
