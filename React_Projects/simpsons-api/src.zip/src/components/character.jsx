import React, { Component } from "react";

class Character extends Component {
  render() {
    return <p>{this.props.character}</p>;
  }
}

export default Character;
