import React from "react";

const Green = (props) => {
  return (
    <>
      {props.active ? (
        <div className="light go on"></div>
      ) : (
        <div className="light go "></div>
      )}
    </>
  );
};

export default Green;
