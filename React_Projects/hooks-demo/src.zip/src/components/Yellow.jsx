import React from "react";

const Yellow = (props) => {
  return (
    <>
      {props.active ? (
        <div className="light caution on"></div>
      ) : (
        <div className="light caution"></div>
      )}
    </>
  );
};

export default Yellow;
