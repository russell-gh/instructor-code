export default {
  theHook: () => {
    //something happens here
  },
};
