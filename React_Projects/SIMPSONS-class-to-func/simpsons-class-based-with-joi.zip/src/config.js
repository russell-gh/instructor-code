export const API_URL = "https://thesimpsonsquoteapi.glitch.me/quotes?count=50";
