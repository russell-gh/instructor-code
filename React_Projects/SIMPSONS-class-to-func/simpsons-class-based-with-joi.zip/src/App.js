import React, { Component } from "react";
import Axios from "axios";
import { API_URL } from "./config";
import Interface from "./components/Interface";
import "./App.css";

class App extends Component {
  state = {};

  componentDidMount() {
    this.getApiData();
  }

  onDelete = (character) => {
    const currentIndex = this.state.apiData.findIndex((item) => {
      return (
        item.character === character.character && item.quote === character.quote
      );
    });

    const apiData = this.state.apiData;
    apiData.splice(currentIndex, 1);
    this.setState({ apiData });
  };

  toggleLike = (character) => {
    const currentIndex = this.state.apiData.findIndex((item) => {
      return (
        item.character === character.character && item.quote === character.quote
      );
    });

    const apiData = [...this.state.apiData];
    apiData[currentIndex].liked = apiData[currentIndex].liked
      ? undefined
      : true;

    this.setState({ apiData });
  };

  getApiData = async () => {
    try {
      const { data: apiData } = await Axios.get(API_URL);

      const unique = [];

      //deduplicate
      apiData.forEach((character) => {
        const index = unique.findIndex((item) => {
          return character.character === item.character;
        });

        if (index === -1) {
          unique.push(character);
        }
      });

      this.setState({ apiData: unique });
    } catch (error) {
      alert("The API down!");
    }
  };

  render() {
    console.log(this.state);

    return (
      <>
        <button onClick={this.getApiData}>Get NEW Simpsons Characters</button>
        <Interface
          toggleLike={this.toggleLike}
          apiData={this.state.apiData}
          onDelete={this.onDelete}
        />
      </>
    );
  }
}

export default App;
