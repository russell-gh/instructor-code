export function joiDataReorder(details) {
  const errorsMod = {};
  details.forEach((error) => {
    // console.log(error);
    errorsMod[error.context.key] = error.message;
  });

  return errorsMod;
}
