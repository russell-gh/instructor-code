import React, { Component } from "react";

class Controls extends Component {
  render() {
    const { onDelete, index } = this.props;

    return (
      <button
        onClick={() => {
          onDelete(index);
        }}
      >
        Delete
      </button>
    );
  }
}

export default Controls;
