import React, { Component } from "react";
import Characters from "./Characters";

class Interface extends Component {
  render() {
    return this.props.apiData ? (
      <Characters
        toggleLike={this.props.toggleLike}
        apiData={this.props.apiData}
        onDelete={this.props.onDelete}
      />
    ) : (
      <p>Loading API data</p>
    );
  }
}

export default Interface;
