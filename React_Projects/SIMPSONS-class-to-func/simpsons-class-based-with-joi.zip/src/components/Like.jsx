import React, { Component } from "react";

class Like extends Component {
  render() {
    const { character, toggleLike } = this.props;

    return (
      <>
        {character.liked && "You like this character"}
        <button onClick={() => toggleLike(character)}>Like</button>
      </>
    );
  }
}

export default Like;
