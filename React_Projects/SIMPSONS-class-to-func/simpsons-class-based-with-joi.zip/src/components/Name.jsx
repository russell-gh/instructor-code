import React, { Component } from "react";

class Name extends Component {
  render() {
    return (
      <div>
        <h4>{this.props.name}</h4>
      </div>
    );
  }
}

export default Name;
