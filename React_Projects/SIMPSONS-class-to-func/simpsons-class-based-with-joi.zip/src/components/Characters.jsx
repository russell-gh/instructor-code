import React, { Component } from "react";
import Character from "./Character";
import LikedStats from "./LikeStats";
import Joi from "joi";
import { joiDataReorder } from "../utils";

class Characters extends Component {
  state = { data: {}, errors: {} };

  schema = {
    userInput: Joi.string().required().min(3),
  };

  onInput = async (e) => {
    const data = { ...this.state.data, userInput: e.target.value };

    this.setState({ data });

    const _joiInstance = Joi.object(this.schema);
    try {
      await _joiInstance.validateAsync(data);
      this.setState({ errors: {} });
    } catch (errors) {
      this.setState({ errors: joiDataReorder(errors.details) });
      console.log("Error", errors);
    }
  };

  render() {
    const { apiData, onDelete, toggleLike } = this.props;
    const { userInput } = this.state.data;

    let result = [...apiData];

    if (userInput) {
      result = result.filter((item) => {
        return item.character
          .toLowerCase()
          .includes(userInput && userInput.toLowerCase());
      });
    }

    result.sort((item1, item2) => {
      const first = item1.character.toLowerCase();
      const second = item2.character.toLowerCase();
      return first < second ? -1 : first > second ? 1 : 0;
    });

    return (
      <>
        <LikedStats characters={apiData} />

        <input onInput={this.onInput} name="userInput" type="text" />
        {this.state.errors.userInput}

        {result.map((character, index) => {
          return (
            <div key={index} className="character">
              <Character
                index={character}
                character={character}
                onDelete={onDelete}
                toggleLike={toggleLike}
              />
            </div>
          );
        })}
      </>
    );
  }
}

export default Characters;
