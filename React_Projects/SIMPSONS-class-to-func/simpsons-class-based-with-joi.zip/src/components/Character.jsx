import React, { Component } from "react";
import Name from "./Name";
import Quote from "./Quote";
import Image from "./Image";
import Controls from "./Controls";
import Like from "./Like";

class Character extends Component {
  render() {
    const { character, index, onDelete } = this.props;

    return (
      <>
        <Name name={character.character} />
        <Image image={character.image} />
        <Quote quote={character.quote} />
        <Controls index={index} onDelete={onDelete} />
        <Like toggleLike={this.props.toggleLike} character={character} />
      </>
    );
  }
}

export default Character;
