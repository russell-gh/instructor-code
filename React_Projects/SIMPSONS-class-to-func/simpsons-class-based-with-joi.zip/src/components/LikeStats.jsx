import React, { Component } from "react";

class LikeStats extends Component {
  render() {
    const totalLiked = this.props.characters.filter(
      (character) => character.liked === true
    );

    return <h3>{totalLiked.length}</h3>;
  }
}

export default LikeStats;
