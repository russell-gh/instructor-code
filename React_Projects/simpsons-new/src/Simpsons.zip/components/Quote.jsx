const Quote = (props) => {
  return <p>{props.text}</p>;
};

export default Quote;
