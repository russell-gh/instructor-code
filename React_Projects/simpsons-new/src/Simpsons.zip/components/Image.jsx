const Image = (props) => {
  return <img alt={props.text} src={props.image} />;
};

export default Image;
