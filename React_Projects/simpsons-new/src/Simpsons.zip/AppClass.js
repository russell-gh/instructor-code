import React, { Component } from "react";
import axios from "axios";
import Characters from "./components/Characters";
import "./App.css";

class App extends Component {
  state = {};

  componentDidMount() {
    this.getApiData();
  }

  async getApiData() {
    try {
      const response = await axios.get(
        "https://thesimpsonsquoteapi.glitch.me/quotes?count=10"
      );
      this.setState({ characters: response.data });
    } catch (error) {
      console.log("Error", error);
      alert("Sorry, the API is down!");
    }
  }

  onDelete = (itemNo) => {
    const characters = [...this.state.characters];
    characters.splice(itemNo, 1);
    this.setState({ characters });
  };

  render() {
    return (
      <>
        {this.state.characters ? (
          <Characters
            onDelete={this.onDelete}
            characters={this.state.characters}
          />
        ) : (
          <div>Loading, please wait</div>
        )}
      </>
    );
  }
}

export default App;
