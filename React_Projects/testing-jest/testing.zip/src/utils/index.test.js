import { add } from "./index";

test("add two numbers", () => {
  expect(add(1, 2)).toBe(3);
});
