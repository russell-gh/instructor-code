# read me

Oh no!!!!

There are a whole bunch of errors in this website and I can't fix them. Can you help me??

1. The first error is at the bottom of every page is a copyright notice, however instead of showing the year, it shows the numbers 123.

2. In the mobile view of the website, the MENU button is not working.

3. The menu item Sessions & Prices leads to a blank page.

4. At the bottom of the homepage, the scrolling testimonials section is glitching out.

5. The Get In Touch button on the homepage (jsut above testimonials) leads to a blank page.

---
