# GTW Hypotherapy

A website created for a clients business built in React and utilising various packages such as React Router Dom, Carousel, and Helmet.

<https://www.gtw-hypnotherapy.co.uk/>

Please visit my portfolio

<https://jon.pitans.co.uk>

and my LinkedIn

<https://www.linkedin.com/in/jon-pitans/>
