//create a reference to the add button in the dom

//create a reference to the remove button in the dom

//create a reference to the count in the dom

//listen for a click on add

//when add is clicked on, increment the count by 1

//do the same for remove

//optional:
//change the price at the same time
