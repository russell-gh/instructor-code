//grab dom references
const items = document.getElementById("items");
const searchInput = document.getElementById("searchInput");
const searchSubmit = document.getElementById("searchSubmit");

//define a list of todos
let todos = [];

items.addEventListener("click", function (event) {
  todos.splice(event.target.id, 1);
  updateDOM(todos);
});

updateDOM(todos);

function updateDOM(todos) {
  if (todos.length > 0) {
    //map over todos and get li tags
    const todosHTML = todos.map(function (item, index) {
      return "<li id='" + index + "'>" + item + "</li>";
    });

    //insert the html into the dom
    items.innerHTML = todosHTML.join("");
  } else {
    items.innerHTML = "<p>Please add an item</p>";
  }
}

function checkIfExists(todos, searchInput) {
  const index = todos.findIndex(function (todo) {
    return todo.toLowerCase() === searchInput.toLowerCase();
  });
  return index;
}

function newTodoItem(todos, searchInput) {
  //add to the todos array
  todos.push(searchInput);

  //update the dom
  updateDOM(todos);
}

//listen for a submit click
//validate the input
//if good trigger update of dom with new data
searchSubmit.addEventListener("click", function () {
  const getIfInArray = checkIfExists(todos, searchInput.value);

  if (searchInput.value.length > 2 && getIfInArray === -1) {
    newTodoItem(todos, searchInput.value);
  } else {
    alert("Sorry, input was empty or already exists!");
  }
});
