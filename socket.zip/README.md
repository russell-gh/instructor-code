# Websockets

1. Install the modules, with `npm i`
2. `npm start`
